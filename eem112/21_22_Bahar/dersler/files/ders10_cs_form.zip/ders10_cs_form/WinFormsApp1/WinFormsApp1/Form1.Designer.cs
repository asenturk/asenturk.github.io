﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbIsim = new System.Windows.Forms.TextBox();
            this.tbSoyIsim = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblMesaj = new System.Windows.Forms.Label();
            this.tbArasinav = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFinal = new System.Windows.Forms.TextBox();
            this.rbDevamVar = new System.Windows.Forms.RadioButton();
            this.rbDevamYok = new System.Windows.Forms.RadioButton();
            this.rbProjeYapti = new System.Windows.Forms.RadioButton();
            this.rbProjeYapmadi = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbOdev1 = new System.Windows.Forms.CheckBox();
            this.cbOdev2 = new System.Windows.Forms.CheckBox();
            this.tbDeneySayisi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbOdev3 = new System.Windows.Forms.CheckBox();
            this.cbOdev4 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "İsim";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyisim";
            // 
            // tbIsim
            // 
            this.tbIsim.Location = new System.Drawing.Point(96, 10);
            this.tbIsim.Name = "tbIsim";
            this.tbIsim.Size = new System.Drawing.Size(100, 23);
            this.tbIsim.TabIndex = 2;
            // 
            // tbSoyIsim
            // 
            this.tbSoyIsim.Location = new System.Drawing.Point(96, 43);
            this.tbSoyIsim.Name = "tbSoyIsim";
            this.tbSoyIsim.Size = new System.Drawing.Size(100, 23);
            this.tbSoyIsim.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(57, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 49);
            this.button1.TabIndex = 5;
            this.button1.Text = "Not Hesapla";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblMesaj
            // 
            this.lblMesaj.AutoSize = true;
            this.lblMesaj.Location = new System.Drawing.Point(497, 18);
            this.lblMesaj.Name = "lblMesaj";
            this.lblMesaj.Size = new System.Drawing.Size(38, 15);
            this.lblMesaj.TabIndex = 6;
            this.lblMesaj.Text = "label3";
            // 
            // tbArasinav
            // 
            this.tbArasinav.Location = new System.Drawing.Point(96, 90);
            this.tbArasinav.Name = "tbArasinav";
            this.tbArasinav.Size = new System.Drawing.Size(100, 23);
            this.tbArasinav.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Arasınav";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(230, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Final";
            // 
            // tbFinal
            // 
            this.tbFinal.Location = new System.Drawing.Point(278, 90);
            this.tbFinal.Name = "tbFinal";
            this.tbFinal.Size = new System.Drawing.Size(100, 23);
            this.tbFinal.TabIndex = 10;
            // 
            // rbDevamVar
            // 
            this.rbDevamVar.AutoSize = true;
            this.rbDevamVar.Location = new System.Drawing.Point(6, 22);
            this.rbDevamVar.Name = "rbDevamVar";
            this.rbDevamVar.Size = new System.Drawing.Size(41, 19);
            this.rbDevamVar.TabIndex = 12;
            this.rbDevamVar.TabStop = true;
            this.rbDevamVar.Text = "Var";
            this.rbDevamVar.UseVisualStyleBackColor = true;
            // 
            // rbDevamYok
            // 
            this.rbDevamYok.AutoSize = true;
            this.rbDevamYok.Location = new System.Drawing.Point(6, 47);
            this.rbDevamYok.Name = "rbDevamYok";
            this.rbDevamYok.Size = new System.Drawing.Size(44, 19);
            this.rbDevamYok.TabIndex = 13;
            this.rbDevamYok.TabStop = true;
            this.rbDevamYok.Text = "Yok";
            this.rbDevamYok.UseVisualStyleBackColor = true;
            // 
            // rbProjeYapti
            // 
            this.rbProjeYapti.AutoSize = true;
            this.rbProjeYapti.Location = new System.Drawing.Point(18, 22);
            this.rbProjeYapti.Name = "rbProjeYapti";
            this.rbProjeYapti.Size = new System.Drawing.Size(51, 19);
            this.rbProjeYapti.TabIndex = 14;
            this.rbProjeYapti.TabStop = true;
            this.rbProjeYapti.Text = "Yaptı";
            this.rbProjeYapti.UseVisualStyleBackColor = true;
            // 
            // rbProjeYapmadi
            // 
            this.rbProjeYapmadi.AutoSize = true;
            this.rbProjeYapmadi.Location = new System.Drawing.Point(18, 47);
            this.rbProjeYapmadi.Name = "rbProjeYapmadi";
            this.rbProjeYapmadi.Size = new System.Drawing.Size(71, 19);
            this.rbProjeYapmadi.TabIndex = 15;
            this.rbProjeYapmadi.TabStop = true;
            this.rbProjeYapmadi.Text = "Yapmadı";
            this.rbProjeYapmadi.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbDevamVar);
            this.groupBox1.Controls.Add(this.rbDevamYok);
            this.groupBox1.Location = new System.Drawing.Point(36, 137);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 79);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Devam mecburiyeti";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbProjeYapti);
            this.groupBox2.Controls.Add(this.rbProjeYapmadi);
            this.groupBox2.Location = new System.Drawing.Point(278, 137);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 79);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Proje";
            // 
            // cbOdev1
            // 
            this.cbOdev1.AutoSize = true;
            this.cbOdev1.Location = new System.Drawing.Point(6, 22);
            this.cbOdev1.Name = "cbOdev1";
            this.cbOdev1.Size = new System.Drawing.Size(63, 19);
            this.cbOdev1.TabIndex = 18;
            this.cbOdev1.Text = "Ödev 1";
            this.cbOdev1.UseVisualStyleBackColor = true;
            // 
            // cbOdev2
            // 
            this.cbOdev2.AutoSize = true;
            this.cbOdev2.Location = new System.Drawing.Point(6, 47);
            this.cbOdev2.Name = "cbOdev2";
            this.cbOdev2.Size = new System.Drawing.Size(63, 19);
            this.cbOdev2.TabIndex = 19;
            this.cbOdev2.Text = "Ödev 2";
            this.cbOdev2.UseVisualStyleBackColor = true;
            // 
            // tbDeneySayisi
            // 
            this.tbDeneySayisi.Location = new System.Drawing.Point(96, 236);
            this.tbDeneySayisi.Name = "tbDeneySayisi";
            this.tbDeneySayisi.Size = new System.Drawing.Size(100, 23);
            this.tbDeneySayisi.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 21;
            this.label5.Text = "Deney Sayısı";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbOdev3);
            this.groupBox3.Controls.Add(this.cbOdev4);
            this.groupBox3.Controls.Add(this.cbOdev1);
            this.groupBox3.Controls.Add(this.cbOdev2);
            this.groupBox3.Location = new System.Drawing.Point(278, 244);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 89);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ödevler";
            // 
            // cbOdev3
            // 
            this.cbOdev3.AutoSize = true;
            this.cbOdev3.Location = new System.Drawing.Point(111, 22);
            this.cbOdev3.Name = "cbOdev3";
            this.cbOdev3.Size = new System.Drawing.Size(63, 19);
            this.cbOdev3.TabIndex = 20;
            this.cbOdev3.Text = "Ödev 3";
            this.cbOdev3.UseVisualStyleBackColor = true;
            // 
            // cbOdev4
            // 
            this.cbOdev4.AutoSize = true;
            this.cbOdev4.Location = new System.Drawing.Point(111, 47);
            this.cbOdev4.Name = "cbOdev4";
            this.cbOdev4.Size = new System.Drawing.Size(63, 19);
            this.cbOdev4.TabIndex = 21;
            this.cbOdev4.Text = "Ödev 4";
            this.cbOdev4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbDeneySayisi);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbFinal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbArasinav);
            this.Controls.Add(this.lblMesaj);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbSoyIsim);
            this.Controls.Add(this.tbIsim);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbIsim;
        private System.Windows.Forms.TextBox tbSoyIsim;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblMesaj;
        private System.Windows.Forms.TextBox tbArasinav;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbFinal;
        private System.Windows.Forms.RadioButton rbDevamVar;
        private System.Windows.Forms.RadioButton rbDevamYok;
        private System.Windows.Forms.RadioButton rbProjeYapti;
        private System.Windows.Forms.RadioButton rbProjeYapmadi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cbOdev1;
        private System.Windows.Forms.CheckBox cbOdev2;
        private System.Windows.Forms.TextBox tbDeneySayisi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbOdev3;
        private System.Windows.Forms.CheckBox cbOdev4;
    }
}

