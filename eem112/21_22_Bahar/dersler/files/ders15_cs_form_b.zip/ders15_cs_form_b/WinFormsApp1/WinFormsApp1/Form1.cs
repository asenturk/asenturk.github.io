﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {    
            Random rnd = new Random();
            int sayi = rnd.Next(100);
            listBox1.Items.Add(sayi.ToString());
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            int eb, i;
            if (listBox1.Items.Count == 0)
            {
                timer1.Enabled = false;
                MessageBox.Show("Tebrikler, kazandiz");
            }
            else
            {
                eb = Convert.ToInt32(listBox1.Items[0]);

                if (listBox1.Items.Count > 0)
                {
                    for (i = 0; i < listBox1.Items.Count; i++)
                    {
                        if (Convert.ToInt32(listBox1.Items[i]) > eb)
                            eb = Convert.ToInt32(listBox1.Items[i]);
                    }
                }
                label1.Text = eb.ToString();
                
                if (listBox1.SelectedItem.ToString() == eb.ToString())
                {
                    //Bu kodda hata veriyor?
                    //listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                    MessageBox.Show("secim doğru");
                }
                timer1.Enabled = true;
            }
        }
    }
}
