﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double direnc1, direnc2, esdeger_direnc=0;
            direnc1 = Convert.ToDouble(textBox1.Text);
            direnc2 = Convert.ToDouble(textBox2.Text);
            if (comboBox1.SelectedItem.ToString() == "Seri")
                esdeger_direnc = direnc1 + direnc2;
            else if (comboBox1.SelectedItem.ToString() == "Paralel")
                esdeger_direnc = (direnc1 * direnc2)/(direnc1 + direnc2);

            textBox3.Text = esdeger_direnc.ToString();

        }
    }
}
