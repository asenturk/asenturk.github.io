﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = dateTimePicker1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = dateTimePicker1.Text;

            DateTime tarih1 = Convert.ToDateTime(label1.Text);
            DateTime tarih2 = Convert.ToDateTime(label2.Text);

            TimeSpan sonuc = tarih1 - tarih2;

            label3.Text = sonuc.ToString();

        }

        int i = 0;

        private void button3_Click(object sender, EventArgs e)
        {
            if (i % 2 == 0)
            {
                monthCalendar1.Visible = false;
                button3.Text = "Takvimi Göster";
            }
            else
            {
                monthCalendar1.Visible = true;
                button3.Text = "Takvimi Gizle";
            }
                

            i++;

        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void yeniFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < 5; i++)
            {
                Form2 form2 = new Form2();
                form2.Show();
            }
            
            
        }
    }
}
